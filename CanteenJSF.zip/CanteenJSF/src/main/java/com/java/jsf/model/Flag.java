package com.java.jsf.model;

public enum Flag {

	VEG, NONVEG
}
